CREATE TABLE CheckInLocation (
    CheckInLocationID int PRIMARY KEY,
    StationName VARCHAR(30) NOT NULL
);
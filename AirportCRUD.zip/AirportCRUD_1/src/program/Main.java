/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package program;

import entity.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author darsh
 */
public class Main extends javax.swing.JFrame {
    private static DAO CheckInLocationDAO, PassengerDAO;
    /**
     * Creates new form Main
     */
    public Main() {
        initComponents();
        refreshCheckInLocationTable();
        refreshPassengersTable();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPaneAirport = new javax.swing.JTabbedPane();
        jPanelCheckInLocation = new javax.swing.JPanel();
        jTextFieldCheckInLocationID = new javax.swing.JTextField();
        jTextFieldStationName = new javax.swing.JTextField();
        jLabelCheckInLocationID = new javax.swing.JLabel();
        jLabelStationName = new javax.swing.JLabel();
        jButtonInsertCheckInLocation = new javax.swing.JButton();
        jButtonUpdateCheckInLocation = new javax.swing.JButton();
        jButtonDeleteCheckInLocation = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableCheckInLocation = new javax.swing.JTable();
        jPanelPassenger = new javax.swing.JPanel();
        jTextFieldPassengerID = new javax.swing.JTextField();
        jTextFieldFirstName = new javax.swing.JTextField();
        jTextFieldLastName = new javax.swing.JTextField();
        dateTimePickerOrderDateTime = new com.github.lgooddatepicker.components.DateTimePicker();
        jTextFieldLocationID = new javax.swing.JTextField();
        jLabelPassengerID = new javax.swing.JLabel();
        jLabelFirstName = new javax.swing.JLabel();
        jLabelLastName = new javax.swing.JLabel();
        jLabelCheckInDateTime = new javax.swing.JLabel();
        jLabelLocationID = new javax.swing.JLabel();
        jButtonInsertpassenger = new javax.swing.JButton();
        jButtonUpdatepassenger = new javax.swing.JButton();
        jButtonDeletepassenger = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTablePassenger = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabelCheckInLocationID.setText("CheckInLocationID:");

        jLabelStationName.setText("StationName:");

        jButtonInsertCheckInLocation.setText("Save");
        jButtonInsertCheckInLocation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonInsertCheckInLocationActionPerformed(evt);
            }
        });

        jButtonUpdateCheckInLocation.setText("Update");
        jButtonUpdateCheckInLocation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonUpdateCheckInLocationActionPerformed(evt);
            }
        });

        jButtonDeleteCheckInLocation.setText("Delete");
        jButtonDeleteCheckInLocation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDeleteCheckInLocationActionPerformed(evt);
            }
        });

        jTableCheckInLocation.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "CheckInLocationID", "StationName"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableCheckInLocation.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableCheckInLocationMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableCheckInLocation);

        javax.swing.GroupLayout jPanelCheckInLocationLayout = new javax.swing.GroupLayout(jPanelCheckInLocation);
        jPanelCheckInLocation.setLayout(jPanelCheckInLocationLayout);
        jPanelCheckInLocationLayout.setHorizontalGroup(
            jPanelCheckInLocationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelCheckInLocationLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelCheckInLocationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelCheckInLocationLayout.createSequentialGroup()
                        .addGroup(jPanelCheckInLocationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabelCheckInLocationID)
                            .addComponent(jLabelStationName))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanelCheckInLocationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextFieldStationName, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextFieldCheckInLocationID, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanelCheckInLocationLayout.createSequentialGroup()
                        .addComponent(jButtonInsertCheckInLocation)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonUpdateCheckInLocation)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonDeleteCheckInLocation)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 452, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(275, Short.MAX_VALUE))
        );
        jPanelCheckInLocationLayout.setVerticalGroup(
            jPanelCheckInLocationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelCheckInLocationLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelCheckInLocationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldCheckInLocationID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelCheckInLocationID))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelCheckInLocationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldStationName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelStationName))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelCheckInLocationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonInsertCheckInLocation)
                    .addComponent(jButtonUpdateCheckInLocation)
                    .addComponent(jButtonDeleteCheckInLocation))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 328, Short.MAX_VALUE)
        );

        jTabbedPaneAirport.addTab("CheckInLocation", jPanelCheckInLocation);

        jTextFieldFirstName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldFirstNameActionPerformed(evt);
            }
        });

        jLabelPassengerID.setText("PassengerID:");

        jLabelFirstName.setText("FirstName:");

        jLabelLastName.setText("LastName:");

        jLabelCheckInDateTime.setText("CheckInDateTime:");

        jLabelLocationID.setText("LocationID:");

        jButtonInsertpassenger.setText("Save");
        jButtonInsertpassenger.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonInsertpassengerActionPerformed(evt);
            }
        });

        jButtonUpdatepassenger.setText("Update");
        jButtonUpdatepassenger.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonUpdatepassengerActionPerformed(evt);
            }
        });

        jButtonDeletepassenger.setText("Delete");
        jButtonDeletepassenger.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDeletepassengerActionPerformed(evt);
            }
        });

        jTablePassenger.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "PassengerID", "FirstName", "LastName", "CheckInDateTime", "LocationID"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTablePassenger.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablePassengerMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTablePassenger);

        javax.swing.GroupLayout jPanelPassengerLayout = new javax.swing.GroupLayout(jPanelPassenger);
        jPanelPassenger.setLayout(jPanelPassengerLayout);
        jPanelPassengerLayout.setHorizontalGroup(
            jPanelPassengerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelPassengerLayout.createSequentialGroup()
                .addGroup(jPanelPassengerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelPassengerLayout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(jLabelPassengerID)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextFieldPassengerID, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanelPassengerLayout.createSequentialGroup()
                        .addGroup(jPanelPassengerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelPassengerLayout.createSequentialGroup()
                                .addGap(46, 46, 46)
                                .addGroup(jPanelPassengerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelFirstName, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabelLastName, javax.swing.GroupLayout.Alignment.TRAILING)))
                            .addGroup(jPanelPassengerLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabelCheckInDateTime))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelPassengerLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabelLocationID)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanelPassengerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dateTimePickerOrderDateTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanelPassengerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jTextFieldFirstName, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                                .addComponent(jTextFieldLastName, javax.swing.GroupLayout.Alignment.LEADING))
                            .addComponent(jTextFieldLocationID, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanelPassengerLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButtonInsertpassenger)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonUpdatepassenger)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonDeletepassenger)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 597, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanelPassengerLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jButtonDeletepassenger, jButtonInsertpassenger, jButtonUpdatepassenger});

        jPanelPassengerLayout.setVerticalGroup(
            jPanelPassengerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelPassengerLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelPassengerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldPassengerID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelPassengerID))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelPassengerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelFirstName)
                    .addComponent(jTextFieldFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(jPanelPassengerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelLastName)
                    .addComponent(jTextFieldLastName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelPassengerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dateTimePickerOrderDateTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelCheckInDateTime))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelPassengerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelLocationID)
                    .addComponent(jTextFieldLocationID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelPassengerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonInsertpassenger)
                    .addComponent(jButtonUpdatepassenger)
                    .addComponent(jButtonDeletepassenger))
                .addContainerGap(158, Short.MAX_VALUE))
            .addGroup(jPanelPassengerLayout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPaneAirport.addTab("Passenger", jPanelPassenger);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jTabbedPaneAirport, javax.swing.GroupLayout.PREFERRED_SIZE, 951, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPaneAirport)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

     //method to clear the check-in location txt fields
    private void clearCheckInLocationTextFields() {
        jTextFieldCheckInLocationID.setText("");
        jTextFieldStationName.setText("");
    }
    
    //method to clear the passenger txt fields
    private void clearPassengerTextFields() {
        jTextFieldPassengerID.setText("");
        jTextFieldFirstName.setText("");
        jTextFieldLastName.setText("");
        jTextFieldLocationID.setText("");
    }
    
    //fetch Check-In Location Table
    private void refreshCheckInLocationTable() {
        List<CheckInLocation> Checkinlocations = CheckInLocationDAO.getAll();
        DefaultTableModel model = (DefaultTableModel) jTableCheckInLocation.getModel();
        //Clear all items in jTableCheckInLocation
        for(int i = model.getRowCount() - 1; i >= 0; i-- ) {
            model.removeRow(i);
        }
        for (CheckInLocation Checkinlocation : Checkinlocations) {
                Object[] row = new Object[2];
                row[0] = Checkinlocation.getCheckInLocationID();
                row[1] = Checkinlocation.getStationName();
                
                model.addRow(row);
        }
    }
    //fetch Passenger Table
    private void refreshPassengersTable() {
        List<Passenger> passengers = PassengerDAO.getAll();
        DefaultTableModel model = (DefaultTableModel) jTablePassenger.getModel();
        //Clear all items in jTablePassenger
        for(int i = model.getRowCount() - 1; i >= 0; i-- ) {
            model.removeRow(i);
        }
        for (Passenger Passenger : passengers) {
                Object[] row = new Object[5];
                row[0] = Passenger.getPassengerID();
                row[1] = Passenger.getFirstName();
                row[2] = Passenger.getLastName();
                row[3] = Passenger.getCheckInDateTime();
                row[4] = Passenger.getCheckInLocationID();
                model.addRow(row);
        }
    }
    
      static CheckInLocation getCheckInLocation(int id) {
        Optional<CheckInLocation> Checkinlocation = CheckInLocationDAO.get(id);
        return Checkinlocation.orElseGet(() -> new CheckInLocation(-1, "Non-exist"));
    }
      static Passenger getPassenger(int id) {
        Optional<Passenger> passenger = PassengerDAO.get(id);
        return passenger.orElseGet(() -> new Passenger(-1, "Non-exist", "Non-exist", "Non-exist", -1));
    }
    
     //method to show an info alert
    public void alert(String msg) {
        JOptionPane.showMessageDialog(rootPane, msg);
    }
    
    //method to check for passenger's check-in location id foreign key violation
    public void foreignKeyViolationPassenger(int id) {
        if(getCheckInLocation(id).getCheckInLocationID() == -1) {
            alert("Check-in location ID does not exist", "Foreign Key Violation");
        }
    }
    
    //method to check for check-in location primary key violation
    public void primaryKeyViolationCheckInLocation(int id) {
        if(getCheckInLocation(id).getCheckInLocationID() != -1) {
            alert("Another check-in location already exists with same location ID, please try another Check-in location ID", "Primary Key Violation");
        }
    }
    
    //method to check for check-in location foreign key violation
    public void foreignKeyViolationCheckInLocation(int id) {
        if(getPassenger(id).getPassengerID() != -1) {
            alert("Passenger exists with the location ID", "Foreign Key Cascade Violation");
        }
    }
    
    //method to check for Passenger primary key violation
    public void primaryKeyViolationPassenger(int id) {
        if(getPassenger(id).getPassengerID() != -1) {
            alert("Another Passenger already exists with same Passenger ID, please try another Passenger ID", "Primary Key Violation");
        }
    }
    
    //method to show an error alert
    public void alert(String msg, String title) {
        JOptionPane.showMessageDialog(rootPane, msg, title, JOptionPane.ERROR_MESSAGE);
    }
    
    /**
     * CheckInLocation CRUD FUNCTIONS
    */
    private static void addCheckInLocation(int CheckInLocationID, String StationName) {
        CheckInLocation Checkinlocation;
        Checkinlocation = new CheckInLocation(CheckInLocationID, StationName);
        CheckInLocationDAO.insert(Checkinlocation);
    }
    
    private static void updateCheckInLocation(int CheckInLocationID, String StationName) {
        CheckInLocation Checkinlocation;
        Checkinlocation = new CheckInLocation(CheckInLocationID, StationName);
        CheckInLocationDAO.update(Checkinlocation);
    }
    
    private static void deleteCheckInLocation(int CheckInLocationID, String StationName) {
        CheckInLocation Checkinlocation;
        Checkinlocation = new CheckInLocation(CheckInLocationID, StationName);
        CheckInLocationDAO.delete(Checkinlocation);
    }
    
    /**
     * Passenger CRUD FUNCTIONS
    */
    private static void addPassenger(int PassengerID, String firstName, String lastName, String CheckInDateTime, int CheckInLocationID) {
        Passenger passenger;
        passenger = new Passenger(PassengerID, firstName, lastName, CheckInDateTime, CheckInLocationID);
        PassengerDAO.insert(passenger);
    }
    
    private static void updatePassenger(int PassengerID, String firstName, String lastName, String CheckInDateTime, int CheckInLocationID) {
        Passenger passenger;
        passenger = new Passenger(PassengerID, firstName, lastName, CheckInDateTime, CheckInLocationID);
        PassengerDAO.update(passenger);
    }
    
    private static void deletePassenger(int PassengerID, String firstName, String lastName, String CheckInDateTime, int CheckInLocationID) {
        Passenger passenger;
        passenger = new Passenger(PassengerID, firstName, lastName, CheckInDateTime, CheckInLocationID);
        PassengerDAO.delete(passenger);
    }
    
    
    private void jTextFieldFirstNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldFirstNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldFirstNameActionPerformed

    private void jTableCheckInLocationMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableCheckInLocationMouseClicked
        // TODO add your handling code here:
        int i = jTableCheckInLocation.getSelectedRow();
        TableModel model = jTableCheckInLocation.getModel();
        jTextFieldCheckInLocationID.setText(model.getValueAt(i, 0).toString());
        jTextFieldStationName.setText(model.getValueAt(i, 1).toString());
       
    }//GEN-LAST:event_jTableCheckInLocationMouseClicked

    private void jTablePassengerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablePassengerMouseClicked
        // TODO add your handling code here:
        int i = jTablePassenger.getSelectedRow();
        TableModel model = jTablePassenger.getModel();
        jTextFieldPassengerID.setText(model.getValueAt(i, 0).toString());
        jTextFieldFirstName.setText(model.getValueAt(i, 1).toString());
        jTextFieldLastName.setText(model.getValueAt(i, 2).toString());
        String datetime = model.getValueAt(i, 3).toString();
        LocalDate date1 = LocalDate.of(Integer.parseInt(datetime.substring(0, 4)) , 
                Integer.parseInt(datetime.substring(5, 7)), Integer.parseInt(datetime.substring(8, 10)));
         LocalTime time1 = LocalTime.of(Integer.parseInt(datetime.substring(11, 13)), Integer.parseInt(datetime.substring(14, 16)));
         dateTimePickerOrderDateTime.datePicker.setDate(date1);
         dateTimePickerOrderDateTime.timePicker.setTime(time1);
         
        jTextFieldLocationID.setText(model.getValueAt(i, 4).toString());
       
    }//GEN-LAST:event_jTablePassengerMouseClicked

    private void jButtonInsertCheckInLocationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonInsertCheckInLocationActionPerformed
        // TODO add your handling code here:
        if (!jTextFieldCheckInLocationID.getText().isEmpty()) {
            int CheckInLocationID = Integer.parseInt(jTextFieldCheckInLocationID.getText().trim());
            String StationName = jTextFieldStationName.getText().trim();
            
            primaryKeyViolationCheckInLocation(CheckInLocationID);
            addCheckInLocation(CheckInLocationID, StationName);
            refreshCheckInLocationTable();
            clearCheckInLocationTextFields();
        }
        else
        {
            alert("ID cannot be empty", "Insert error");
        }
    }//GEN-LAST:event_jButtonInsertCheckInLocationActionPerformed

    private void jButtonUpdateCheckInLocationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonUpdateCheckInLocationActionPerformed
        // TODO add your handling code here:
        if (!jTextFieldCheckInLocationID.getText().isEmpty()) {
            int CheckInLocationID = Integer.parseInt(jTextFieldCheckInLocationID.getText().trim());
            String StationName = jTextFieldStationName.getText().trim();
            
            CheckInLocation Checkinlocation= getCheckInLocation(CheckInLocationID);
            if(Checkinlocation.getCheckInLocationID() != -1) {                
                updateCheckInLocation(CheckInLocationID, StationName);
                refreshCheckInLocationTable();
            }
            else
            {
                alert("Location does not exist", "Update error");
            }
        }
        else
        {
            alert("CheckInLocationID cannot be empty", "Update error");
        }
    
    }//GEN-LAST:event_jButtonUpdateCheckInLocationActionPerformed

    private void jButtonDeleteCheckInLocationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonDeleteCheckInLocationActionPerformed
        // TODO add your handling code here:
         if (!jTextFieldCheckInLocationID.getText().isEmpty()) {
            int CheckInLocationID = Integer.parseInt(jTextFieldCheckInLocationID.getText().trim());
            String StationName = jTextFieldStationName.getText().trim();
           
            CheckInLocation Checkinlocation = getCheckInLocation(CheckInLocationID);
            if(Checkinlocation.getCheckInLocationID() != -1) {
                int option = JOptionPane.showConfirmDialog(rootPane, "Are you sure you want to Delete?", "Delete confirmation", JOptionPane.YES_NO_OPTION);
                if(option == 0) {
                    foreignKeyViolationCheckInLocation(CheckInLocationID);
                    deleteCheckInLocation(CheckInLocationID, StationName);
                    refreshCheckInLocationTable();
                    clearCheckInLocationTextFields();
                }
            }
            else
            {
                alert("Location does not exist", "Delete error");
            }
        }
        else
        {
            alert("CheckInLocationID cannot be empty", "Delete error");
        }
    }//GEN-LAST:event_jButtonDeleteCheckInLocationActionPerformed

    private void jButtonInsertpassengerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonInsertpassengerActionPerformed
        // TODO add your handling code here:
        if (!jTextFieldPassengerID.getText().isEmpty()) {
            int PassengerID = Integer.parseInt(jTextFieldPassengerID.getText().trim());
            String FirstName = jTextFieldFirstName.getText().trim();
            String LastName = jTextFieldLastName.getText().trim();
            String date = dateTimePickerOrderDateTime.datePicker.getDateStringOrEmptyString() + " " + dateTimePickerOrderDateTime.timePicker.getTimeStringOrEmptyString()+":00.0";
            int CheckInLocationID = Integer.parseInt(jTextFieldLocationID.getText().trim());
            primaryKeyViolationPassenger(PassengerID);
            foreignKeyViolationPassenger(CheckInLocationID);
            
            addPassenger(PassengerID, FirstName, LastName, date, CheckInLocationID);
            
            refreshPassengersTable();
            clearPassengerTextFields();
        }
            
        else
        {
            alert("PassengerID cannot be empty", "Insert error");
        }
    }//GEN-LAST:event_jButtonInsertpassengerActionPerformed

    private void jButtonUpdatepassengerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonUpdatepassengerActionPerformed
        // TODO add your handling code here:
        if (!jTextFieldPassengerID.getText().isEmpty()) {
            int PassengerID = Integer.parseInt(jTextFieldPassengerID.getText().trim());
            String FirstName = jTextFieldFirstName.getText().trim();
            String LastName = jTextFieldLastName.getText().trim();
            String date = dateTimePickerOrderDateTime.datePicker.getDateStringOrEmptyString() + " " + dateTimePickerOrderDateTime.timePicker.getTimeStringOrEmptyString()+":00.0";
            int CheckInLocationID = Integer.parseInt(jTextFieldLocationID.getText().trim());
            Passenger passenger = getPassenger(PassengerID);
            if(passenger.getPassengerID() != -1) {
                foreignKeyViolationPassenger(CheckInLocationID);
                updatePassenger(PassengerID, FirstName, LastName, date, CheckInLocationID);
                refreshPassengersTable();
            }
            else
            {
                alert("Passenger does not exist", "Update error");
            }
        }
        else
        {
            alert("PassengerID cannot be empty", "Update error");
        }
    }//GEN-LAST:event_jButtonUpdatepassengerActionPerformed

    private void jButtonDeletepassengerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonDeletepassengerActionPerformed
        // TODO add your handling code here:
        if (!jTextFieldPassengerID.getText().isEmpty()) {
            int PassengerID = Integer.parseInt(jTextFieldPassengerID.getText().trim());
            String FirstName = jTextFieldFirstName.getText().trim();
            String LastName = jTextFieldLastName.getText().trim();
            String date = dateTimePickerOrderDateTime.datePicker.getDateStringOrEmptyString() + " " + dateTimePickerOrderDateTime.timePicker.getTimeStringOrEmptyString()+":00.0";
            int CheckInLocationID = Integer.parseInt(jTextFieldLocationID.getText().trim());
            Passenger passenger = getPassenger(PassengerID);
            if(passenger.getPassengerID() != -1) {
                int option = JOptionPane.showConfirmDialog(rootPane, "Are you sure you want to Delete?", "Delete confirmation", JOptionPane.YES_NO_OPTION);
                if(option == 0) {
                    deletePassenger(PassengerID, FirstName, LastName, date, CheckInLocationID);
                    refreshPassengersTable();
                    clearPassengerTextFields();
                }
            }
            else
            {
                alert("Passenger does not exist", "Delete error");
            }
        }
        else
        {
            alert("PassengerID cannot be empty", "Delete error");
        }
    }//GEN-LAST:event_jButtonDeletepassengerActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        CheckInLocationDAO = new CheckInLocationDAO();
        PassengerDAO = new PassengerDAO();
        
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Main().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.github.lgooddatepicker.components.DateTimePicker dateTimePickerOrderDateTime;
    private javax.swing.JButton jButtonDeleteCheckInLocation;
    private javax.swing.JButton jButtonDeletepassenger;
    private javax.swing.JButton jButtonInsertCheckInLocation;
    private javax.swing.JButton jButtonInsertpassenger;
    private javax.swing.JButton jButtonUpdateCheckInLocation;
    private javax.swing.JButton jButtonUpdatepassenger;
    private javax.swing.JLabel jLabelCheckInDateTime;
    private javax.swing.JLabel jLabelCheckInLocationID;
    private javax.swing.JLabel jLabelFirstName;
    private javax.swing.JLabel jLabelLastName;
    private javax.swing.JLabel jLabelLocationID;
    private javax.swing.JLabel jLabelPassengerID;
    private javax.swing.JLabel jLabelStationName;
    private javax.swing.JPanel jPanelCheckInLocation;
    private javax.swing.JPanel jPanelPassenger;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPaneAirport;
    private javax.swing.JTable jTableCheckInLocation;
    private javax.swing.JTable jTablePassenger;
    private javax.swing.JTextField jTextFieldCheckInLocationID;
    private javax.swing.JTextField jTextFieldFirstName;
    private javax.swing.JTextField jTextFieldLastName;
    private javax.swing.JTextField jTextFieldLocationID;
    private javax.swing.JTextField jTextFieldPassengerID;
    private javax.swing.JTextField jTextFieldStationName;
    // End of variables declaration//GEN-END:variables
}
